<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200;600&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <title><?php echo e(env('APP_NAME')); ?></title>
</head>
<body>
    <div id="app">
          <v-app>
            <app-dashboard></app-dashboard>
        </v-app>   
    </div>

    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
</body>
</html><?php /**PATH G:\assignment\laravel-8-Crud-Api\resources\views/welcome.blade.php ENDPATH**/ ?>